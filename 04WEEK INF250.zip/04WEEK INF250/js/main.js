const today = new Date();
document.getElementById('year').textContent = today.getFullYear();